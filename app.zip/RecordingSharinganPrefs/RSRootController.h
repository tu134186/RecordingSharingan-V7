#import <Preferences/PSListController.h>
@interface RSRootController : PSListController
- (void)resetDefaults;
@end
