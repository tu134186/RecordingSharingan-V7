#import "RSRootController.h"
#import <Preferences/PSSpecifier.h>
#import <CoreFoundation/CoreFoundation.h>
#import <Preferences/PSSpecifier.h>
#import <os/log.h>
@implementation RSRootController
- (NSArray *)specifiers {
 if (!_specifiers) {
  NSString *root = [[NSBundle bundleForClass:[self class]] pathForResource:@"Root" ofType:@"plist"];
  NSLog(@"[RecordingSharinganPrefs] controller loaded, Root.plist=%@, bundle=%@", root ?: @"MISSING", [NSBundle bundleForClass:[self class]].bundlePath);
  NSArray *loaded = [self loadSpecifiersFromPlistName:@"Root" target:self];
  if (loaded.count) {
   _specifiers = loaded;
  } else {
   NSLog(@"[RecordingSharinganPrefs] ERROR: Root specifiers missing or empty");
   PSSpecifier *error = [PSSpecifier preferenceSpecifierNamed:@"设置加载失败：Root.plist 未读取" target:self set:NULL get:NULL detail:Nil cell:PSStaticTextCell edit:Nil];
   _specifiers = @[error];
  }
 }
 return _specifiers;
}
- (void)resetDefaults {
 NSString *domain=@"com.tu.recordingsharingan.settings";
 NSDictionary *defaults=@{@"rotationSpeed":@1.0,@"leftXOffset":@0.0,@"rightXOffset":@0.0,@"yOffset":@0.0,@"leftSize":@31.0,@"rightSize":@37.0};
 for(NSString *key in defaults)CFPreferencesSetAppValue((__bridge CFStringRef)key,(__bridge CFPropertyListRef)defaults[key],(__bridge CFStringRef)domain);
 CFPreferencesAppSynchronize((__bridge CFStringRef)domain);
 CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),CFSTR("com.tu.recordingsharingan.settings.changed"),NULL,NULL,YES);
 [self reloadSpecifiers];
}
@end
