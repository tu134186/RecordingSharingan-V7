#import "RSAdjustCell.h"
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>
#import <math.h>
static NSString *const domain = @"com.tu.recordingsharingan.settings";
static NSString *const notification = @"com.tu.recordingsharingan.settings.changed";
@interface RSAdjustCell ()
@property(nonatomic,strong) UISlider *slider;
@property(nonatomic,strong) UILabel *number;
@property(nonatomic,strong) UIButton *minus;
@property(nonatomic,strong) UIButton *plus;
@end
@implementation RSAdjustCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuse specifier:(PSSpecifier *)spec {
 self=[super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse specifier:spec]; if(!self)return nil;
 _slider=[UISlider new];_number=[UILabel new];_minus=[UIButton buttonWithType:UIButtonTypeSystem];_plus=[UIButton buttonWithType:UIButtonTypeSystem];
 [_minus setTitle:@"−" forState:UIControlStateNormal];[_plus setTitle:@"+" forState:UIControlStateNormal];
 _minus.titleLabel.font=[UIFont boldSystemFontOfSize:25];_plus.titleLabel.font=[UIFont boldSystemFontOfSize:25];
 _number.font=[UIFont monospacedDigitSystemFontOfSize:14 weight:UIFontWeightMedium];_number.textAlignment=NSTextAlignmentRight;
 [_slider addTarget:self action:@selector(slide:) forControlEvents:UIControlEventValueChanged];
 [_minus addTarget:self action:@selector(decrease) forControlEvents:UIControlEventTouchUpInside];[_plus addTarget:self action:@selector(increase) forControlEvents:UIControlEventTouchUpInside];
 for(UIView *v in @[_slider,_number,_minus,_plus]) [self.contentView addSubview:v];
 self.selectionStyle=UITableViewCellSelectionStyleNone;[self reload];return self;
}
- (void)refreshCellContentsWithSpecifier:(PSSpecifier *)spec { [super refreshCellContentsWithSpecifier:spec];[self reload]; }
- (void)reload {
 self.textLabel.text=self.specifier.name;self.slider.minimumValue=[[self.specifier propertyForKey:@"min"] floatValue];self.slider.maximumValue=[[self.specifier propertyForKey:@"max"] floatValue];
 NSString *key=[self.specifier propertyForKey:@"key"];CFPreferencesAppSynchronize((__bridge CFStringRef)domain);
 CFPropertyListRef val=CFPreferencesCopyAppValue((__bridge CFStringRef)key,(__bridge CFStringRef)domain);
 float v=val?[(__bridge id)val floatValue]:[[self.specifier propertyForKey:@"default"] floatValue];if(val)CFRelease(val);
 self.slider.value=fmaxf(self.slider.minimumValue,fminf(self.slider.maximumValue,v));[self showValue];
}
- (void)layoutSubviews { [super layoutSubviews];CGFloat w=self.contentView.bounds.size.width;
 self.textLabel.frame=CGRectMake(16,3,w-32,27);
 self.minus.frame=CGRectMake(12,34,36,38);self.plus.frame=CGRectMake(w-52,34,36,38);
 self.number.frame=CGRectMake(w-111,4,95,25);self.slider.frame=CGRectMake(55,38,MAX(30,w-115),30);
}
- (void)showValue {self.number.text=[NSString stringWithFormat:@"%.1f",self.slider.value];}
- (void)save { NSString *key=[self.specifier propertyForKey:@"key"];if(!key)return;
 CFPreferencesSetAppValue((__bridge CFStringRef)key,(__bridge CFPropertyListRef)@(self.slider.value),(__bridge CFStringRef)domain);
 CFPreferencesAppSynchronize((__bridge CFStringRef)domain);
 CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),(__bridge CFStringRef)notification,NULL,NULL,YES);[self showValue];}
- (void)slide:(UISlider *)s {[self save];}
- (void)decrease {[self adjust:-0.5f];}
- (void)increase {[self adjust:0.5f];}
- (void)adjust:(float)d {self.slider.value=fmaxf(self.slider.minimumValue,fminf(self.slider.maximumValue,roundf((self.slider.value+d)*2)/2));[self save];}
@end
