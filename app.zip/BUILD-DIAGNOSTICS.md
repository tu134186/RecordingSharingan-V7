# RecordingSharingan 6.5 diagnostics

This is a source-only experimental build, not a validated fix.

- Replaced unresolved dynamic lookup with explicit private Preferences framework linkage. Requires private SDK framework stub.
- Added NSLog diagnostics to RSRootController.specifiers, plus a visible error cell when Root.plist cannot load.
- No modifications to Tweak.xm or existing recording hooks.
- After packaging, inspect: dpkg-deb -c <deb> | grep -E "RecordingSharinganPrefs|PreferenceLoader"
- In device Settings process logs, search for [RecordingSharinganPrefs].
- If linker says framework Preferences not found, fix SDK setup; do not remove dependency blindly.
