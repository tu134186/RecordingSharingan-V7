# 7.11.9.4.3.2.6.2

修复 GitHub 云编译 `ld: framework Preferences not found`：不链接缺失的私有 framework，改为在 PreferenceLoader 已加载 Preferences.framework 的设置进程内动态解析 Objective-C 符号。

只修改 PreferenceBundle Makefile、control 版本及 VERSION.txt；Tweak.xm 完全不变。

注意：本方案需要云编译验证链接器支持 `-undefined dynamic_lookup`，并需真机验证设置页面加载。未进行云编译或真机验证。
